from django.apps import AppConfig


class Nexus360Config(AppConfig):
    name = 'Nexus_360'
